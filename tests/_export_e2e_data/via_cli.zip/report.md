Raft 是 leader-based 共识算法[^a]，Paxos 则是经典的多数决算法[^b]。
另外参考一份历史文档[^g]。

[^a]: entry_id=019e5531-be18-7fc5-872e-86e49285daf8, section_id=s2 - 第二节给出选举流程的伪代码
[^b]: entry_id=019e5531-be18-7bef-9543-987a7d801fda - 整篇文档讲 Paxos
[^g]: entry_id=019e5531-be18-7f9d-acfe-384d3854465b - 历史对比，可能已删除
